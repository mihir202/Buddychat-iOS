# BUDDYCHAT – A REALTIME CHAT APP


#  Overview

Buddychat app aims to provide users with access to all chat app
functionality alogng with latest trend update happening in any area all
around the world

# Motivation
Rather than using two different app to know about the latest
trend(Channel feature) and real-time messaging, I intend to aggregate
and display them all at once.

## Features
• One on one chat

• Channels

• Multimedia messages (Photo, Video, Audio, Location)

• Custom UI Collection views

• Custom UI Tableviews

## Features (BACKEND)
• Firebase storage

• Firebase Firestore

• Firebase Cloud Messaging

• Firebase users Authentication

<img width="1144" alt="Screen Shot 2021-05-19 at 9 50 44 PM" src="https://user-images.githubusercontent.com/17905933/118906744-5acb5600-b8ec-11eb-8e24-d872da02ed09.png">


<img width="1019" alt="Screen Shot 2021-05-19 at 9 50 56 PM" src="https://user-images.githubusercontent.com/17905933/118906762-6028a080-b8ec-11eb-92fa-3115965aa6b0.png">






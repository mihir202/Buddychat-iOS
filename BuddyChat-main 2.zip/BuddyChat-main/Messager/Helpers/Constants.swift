//
//  Constants.swift
//  Messager
//
//  Created by Mihir Patel on 17/08/2020.
//

import Foundation

let userDefaults = UserDefaults.standard
public let kFILEREFERENCE = "gs://buddychat-a118d.appspot.com"
public let kSERVERKEY = "AAAAYaDnss0:APA91bHFwsxb0AaUaSYCVBQ3Lf8xquN1GHfOy6am4CvpeCA3efHs_vNeVm1byY_lKbJFF-q2Cv5h7Glm6KNgsdnPexOlVlZwaLPCyf6oahNh0rSkKu01Net-aU3ZT-rx1E0e7wWkWwOj"



public let kNUMBEROFMESSAGES = 12


public let kCURRENTUSER = "currentUser"
public let kSTATUS = "status"
public let kFIRSTRUN = "firstRUN"

public let kCHATROOMID = "chatRoomId"
public let kSENDERID = "senderId"

public let kSENT = "Sent"
public let kREAD = "Read"

public let kTEXT = "text"
public let kPHOTO = "photo"
public let kVIDEO = "video"
public let kAUDIO = "audio"
public let kLOCATION = "location"


public let kDATE = "date"
public let kREADDATE = "date"

public let kADMINID = "adminId"
public let kMEMBERIDS = "memberIds"
